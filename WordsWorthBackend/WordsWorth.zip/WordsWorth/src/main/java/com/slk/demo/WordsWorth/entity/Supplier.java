package com.slk.demo.WordsWorth.entity;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;




@Entity
@Table(name="Supplier")
public class Supplier {


	
	@Id
	@Column(name="SUPPLIERID")
	private int supplierId;
	@Column(name="SUPPLIERNAME")
	private String suppliername;
	@Column(name="EMAIL")
	private String email;
	@Column(name="CONTACT")
	private long contact;
	@Column(name="PASSWORD")
	private String password;
	@Column(name="ADDRESS")
	private String address;
	@Column(name="SUPPLYSTATUS")
	private String supplystatus;


	public Supplier() {
		
	}


	public Supplier(int supplierId, String suppliername, String email, long contact, String password, String address,
			String supplystatus) {
		this.supplierId = supplierId;
		this.suppliername = suppliername;
		this.email = email;
		this.contact = contact;
		this.password = password;
		this.address = address;
		this.supplystatus = supplystatus;
	}


	public int getSupplierId() {
		return supplierId;
	}


	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}


	public String getSuppliername() {
		return suppliername;
	}


	public void setSuppliername(String suppliername) {
		this.suppliername = suppliername;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public long getContact() {
		return contact;
	}


	public void setContact(long contact) {
		this.contact = contact;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getSupplystatus() {
		return supplystatus;
	}


	public void setSupplystatus(String supplystatus) {
		this.supplystatus = supplystatus;
	}


	@Override
	public String toString() {
		return "Supplier [supplierId=" + supplierId + ", suppliername=" + suppliername + ", email=" + email
				+ ", contact=" + contact + ", password=" + password + ", address=" + address + ", supplystatus="
				+ supplystatus + "]";
	}


	
	
}
	
	