package com.slk.demo.WordsWorth.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.slk.demo.WordsWorth.entity.Admin;
import com.slk.demo.WordsWorth.repository.AdminRepository;

@Service
public class AdminService {
	
	
	@Autowired
	AdminRepository repo;
	
	public List<Admin> listAllAdmin(){
		List<Admin> admin = repo.findAll();
		return admin;
	}
	
	public Admin getAdminId(int id) {
		Admin admin = repo.findByAdminId(id);
		return admin;
	}
	
	public Admin getAdminByEmail(String email) {
		Admin emails = repo.findByEmail(email);
		return emails;
	}
	
	
	public Admin saveCustomer(Admin admin) {
		Admin admin1 = repo.findTopByOrderByAdminIdDesc();
		int id=1;
		if(admin1 !=null) {
			id = admin1.getAdminId() + 1;
		}
		admin.setAdminId(id);
		
		admin1 = repo.save(admin);
		return admin1;
		
	}
	
	public void deleteByAdminId(int theId) {
		
		repo.deleteById(theId);
	}
	
	public int updatePasswordByadminId(int id,String pass) {
		int res = repo.updatePass(id, pass);
		return res;
	}
}
