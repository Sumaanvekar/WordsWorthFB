package com.slk.demo.WordsWorth.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.slk.demo.WordsWorth.entity.Order;

public interface OrderRepository extends JpaRepository<Order,Integer> {
	
	public List<Order> getOrderByCustomerId(int id);
	
	public Order deleteOrderByOrderId(int id);

	public Order findTopByOrderByOrderIdDesc();

}
