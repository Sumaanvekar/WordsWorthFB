package com.slk.demo.WordsWorth.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slk.demo.WordsWorth.entity.Books;
import com.slk.demo.WordsWorth.entity.Order;
import com.slk.demo.WordsWorth.repository.BooksRepository;

@Service
public class BooksService {
	
	@Autowired
	BooksRepository repo;
	
	//find all
	//find by id
	//save for update and insertion 
	//delete
	
	
	///////get all books
	
	public List<Books> listAllBooks(){
		List<Books> books = repo.findAll();
		return books;
	}
	
    ///////get book by id

	public Books findById(int bId) {
		Books books1 = repo.findByBookId(bId);
		return books1;
	}
     ///////get book by category 
	
	public List<Books> findByCategory(String bcat) {
		List<Books> books2 = repo.findByCategory(bcat);
		return books2;
	}
	
	public List<Books> findByAuthor(String bauthor) {
		List<Books> books = repo.findByAuthor(bauthor);
		return books;
	}
	
	public List<Books> findByPrice(double bmin,double bmax) {
		List<Books> books6 = repo.findAllBetweenPrice(bmin, bmax);
		return books6;
	}
	
	////////get book by name
	
	public Books findByBookName(String bname) {
		Books books = repo.findByBookName(bname);
		return books;
	}
	
     ////////save or update for all
	
//	public Books save(Books thebook) {
//		Books books4=repo.save(thebook);
//		return books4;
//	}
//	
	public void deleteById(int bId ) {
		repo.deleteById(bId);
	}
	
	public Books postBook(Books thebook) {
		Books o=repo.findTopByOrderByBookIdDesc();
		int id=1;
		if(o!=null) {
			id=o.getBookId()+1;
		}
		thebook.setBookId(id);
		o=repo.save(thebook);
		return o;
			
	}
//	public Books savethebook(Books thebook) {
//		Books books4=repo.save(thebook);
//		return books4;
//	}
	

}
