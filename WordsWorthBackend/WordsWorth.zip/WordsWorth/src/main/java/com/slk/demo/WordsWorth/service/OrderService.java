package com.slk.demo.WordsWorth.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.stereotype.Service;

import com.slk.demo.WordsWorth.entity.Order;
import com.slk.demo.WordsWorth.repository.OrderRepository;

@Service
public class OrderService  {
	// Dependancy Enjection
	@Autowired
	OrderRepository orepo;
	
	//Get All the Orders
	public List<Order> getAllOrders(){
		return orepo.findAll();	
	}
	
	
	// Post Order
	public Order postOrder(Order theorder) {
		Order o=orepo.findTopByOrderByOrderIdDesc();
		int id=1;
		if(o!=null) {
			id=o.getOrderId()+1;
		}
		theorder.setOrderId(id);
		o=orepo.save(theorder);
		return o;
			
	}
	
	// Get Oders by customer Id
	public List<Order> getOrderByCustomerId( int id) {
		return orepo.getOrderByCustomerId(id);
	}
	
	// cancel order 
	public String deleteOrderByOrderId(int orderId) {
		Order o= orepo.deleteOrderByOrderId(orderId);
		String str="Order not cancelled";
		if(o!=null) {
			str= "Order Cancelled Successfully";
		}
		return str;
			
	}
	

}
