package com.slk.demo.WordsWorth.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Admin")
public class Admin {
	@Id
	//@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="MySequence")
	@Column(name="ADMINID")
	private int adminId;
	@Column(name="EMAIL")
	private String email;
	@Column(name="PASSWORD")
	private String passWord;
	
	public Admin() {
		
	}
	
	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	
	public Admin(int adminId, String email, String passWord) {
		this.adminId = adminId;
		this.email = email;
		this.passWord = passWord;
	}
	
	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", email=" + email + ", passWord=" + passWord + "]";
	}
	
	

	
	
	
	
}
