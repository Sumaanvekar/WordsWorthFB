package com.slk.demo.WordsWorth.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.slk.demo.WordsWorth.entity.Books;

@Repository
public interface BooksRepository extends JpaRepository<Books,Integer> {
	public Books findByBookId(int bId);
	public Books findByBookName(String bname);
	public List<Books> findByCategory(String bcat);
	public List<Books> findByAuthor(String bauthor);
	//public List<Books> findByPrice(double bprice);
	public Books save(Books thebook);
	public void deleteById(int bId);
	public Books findTopByOrderByBookIdDesc();
	
	@Query(value="select * from books where price between :min and :max",nativeQuery=true)
	public List<Books> findAllBetweenPrice(@Param("min") double min ,@Param("max") double max);
	
//	@Modifying
//	@Query("UPDATE Books u SET u.pass = :pass WHERE u.studentId = :id")
//	public int UpdateBook(@Param ("id") int id,@Param("pass") String pass);


}
