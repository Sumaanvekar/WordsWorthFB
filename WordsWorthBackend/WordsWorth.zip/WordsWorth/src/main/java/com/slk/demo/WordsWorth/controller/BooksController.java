package com.slk.demo.WordsWorth.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.slk.demo.WordsWorth.entity.Books;
import com.slk.demo.WordsWorth.service.BooksService;


@RestController
@RequestMapping("/api")
@CrossOrigin(origins="http://localhost:4200")
public class BooksController {
	@Autowired	
	BooksService service;
	

@GetMapping("/books")
	public List<Books> listAllBooks(){
	
		return service.listAllBooks();
		
		}

@GetMapping("/books/bid/{id}")
public Books getBookById(@PathVariable int id) {
	
	Books books= service.findById(id);
	
	return books;
	
}
@GetMapping("/books/bcat/{category}")
public List<Books> getBookByCategory(@PathVariable String category) {
	
	List<Books> books= service.findByCategory(category);
	
	return books;
	
}

@GetMapping("/books/bname/{name}")
public Books getBookByName(@PathVariable String name) {
	Books books= service.findByBookName(name);
	
	return books;
	
}
@GetMapping("/books/bauthor/{aname}")
public List<Books> getBookByAuthor(@PathVariable String aname) {
	
	List<Books> books= service.findByAuthor(aname);
	
	return books;
	
}
@GetMapping("/books/bprice/{price}/{bprice}")
public List<Books> getBookByPrice(@PathVariable double price,@PathVariable double bprice) {
	
	List<Books> books= service.findByPrice(price, bprice);
	
	return books;
	
}

@PutMapping("/books")
public Books updateBook(@RequestBody Books theBook)
{
	Books book =service.postBook(theBook);
	return book;
}


@PostMapping("/books")
public Books addBooks(@RequestBody Books theBook)
{
	Books book = service.postBook(theBook);
	return book;
}

@DeleteMapping("/books/bd/{theId}")
public void deleteById(@PathVariable int theId)
{
	 service.deleteById(theId);

}



}
