package com.slk.demo.WordsWorth.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Books")
//@SequenceGenerator(name="MySequence",sequenceName="BOOK_SEQUENCE",initialValue=50,allocationSize=1)

public class Books {
	
	
	@Id
//@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="MySequence")
	@Column(name="BOOKID")
	private int bookId;
	
	@Column(name="SUPPLIERID")
	private int supplierId;
	@Column(name="BOOKNAME")
	private String bookName;
	@Column(name="AUTHOR")
	private String author;
	@Column(name="PRICE")
	private double price;
	@Column(name="CATEGORY")
	private String category;
	@Column(name="BOOKQUANTITY")
	private int bookQuantity;
	@Column(name="BOOKAVAILABILITY")
	private boolean bookAvailabilty;
	
	
	public Books() {
		
	}


	public int getBookId() {
		return bookId;
	}


	public void setBookId(int bookId) {
		this.bookId = bookId;
	}


	public int getSupplierId() {
		return supplierId;
	}


	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}


	public String getBookName() {
		return bookName;
	}


	public void setBookName(String bookName) {
		this.bookName = bookName;
	}


	public String getAuthorName() {
		return author;
	}


	public void setAuthorName(String authorName) {
		this.author = authorName;
	}


	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}


	public int getBookQuantity() {
		return bookQuantity;
	}


	public void setBookQuantity(int bookQuantity) {
		this.bookQuantity = bookQuantity;
	}


	public boolean isBookAvailabilty() {
		return bookAvailabilty;
	}


	public void setBookAvailabilty(boolean bookAvailabilty) {
		this.bookAvailabilty = bookAvailabilty;
	}


	public Books(int bookId, int supplierId, String bookName, String authorName, double price, String category,
			int bookQuantity, boolean bookAvailabilty) {
		this.bookId = bookId;
		this.supplierId = supplierId;
		this.bookName = bookName;
		this.author = authorName;
		this.price = price;
		this.category = category;
		this.bookQuantity = bookQuantity;
		this.bookAvailabilty = bookAvailabilty;
	}


	@Override
	public String toString() {
		return "Books [bookId=" + bookId + ", supplierId=" + supplierId + ", bookName=" + bookName + ", authorName="
				+ author + ", price=" + price + ", category=" + category + ", bookQuantity=" + bookQuantity
				+ ", bookAvailabilty=" + bookAvailabilty + "]";
	}
	
	
	

}
