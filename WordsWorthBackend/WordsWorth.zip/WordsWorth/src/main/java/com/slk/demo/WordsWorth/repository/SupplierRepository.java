package com.slk.demo.WordsWorth.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.slk.demo.WordsWorth.entity.Supplier;


public interface SupplierRepository  extends JpaRepository<Supplier, Integer>{
	
	public Supplier findBySupplierId(int id);
	public Supplier findByEmail(String emailId);
	public Supplier save(Supplier theSupplier);
	public void deleteById(int theId);
	

}
