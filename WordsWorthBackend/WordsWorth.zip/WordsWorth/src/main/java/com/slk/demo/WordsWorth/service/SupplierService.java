package com.slk.demo.WordsWorth.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slk.demo.WordsWorth.entity.Supplier;
import com.slk.demo.WordsWorth.repository.SupplierRepository;


@Service
public class SupplierService {
	
	@Autowired
	SupplierRepository repo;
	
	public List<Supplier> listAllSupplier(){
		List<Supplier> suppliers = repo.findAll();
		return suppliers;
	}
	
	
	public Supplier getSupplierById(int id) {
		Supplier supplier = repo.findBySupplierId(id);
		return supplier;
	}
		public Supplier getSupplierByEmail(String emailId) 
		{
			Supplier supplier = repo.findByEmail(emailId);
			return supplier;
		}
		
		public Supplier save(Supplier theSupplier) {
			
			Supplier sp = repo.save(theSupplier);
			return sp;
		}
		
		public void deleteById(int theId) {
			
			repo.deleteById(theId);
		}
	}

					
	


