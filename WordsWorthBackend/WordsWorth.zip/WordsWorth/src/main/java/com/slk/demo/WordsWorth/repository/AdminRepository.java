package com.slk.demo.WordsWorth.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.slk.demo.WordsWorth.entity.Admin;

@Repository
public interface AdminRepository extends JpaRepository<Admin,Integer>{
	public Admin findByAdminId(int theId );
	public Admin findByEmail(String email);
	
	public Admin findTopByOrderByAdminIdDesc();
	
	@Modifying
	@Query("UPDATE Admin a SET a.passWord =:pass WHERE a.adminId =:id")
	public int updatePass(@Param("id") int id, @Param("pass") String pass );
	
}
