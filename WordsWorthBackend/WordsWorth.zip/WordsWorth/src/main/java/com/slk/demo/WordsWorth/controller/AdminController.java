package com.slk.demo.WordsWorth.controller;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.slk.demo.WordsWorth.entity.Admin;
import com.slk.demo.WordsWorth.service.AdminService;



@CrossOrigin(origins="http://localhost:4200")
@RestController

@RequestMapping("/api")
public class AdminController {
	
	@Autowired
	private AdminService service;
	
	@GetMapping("/admin")
	public List<Admin> listAllAdmin(){
		return service.listAllAdmin();
	}
	

	@GetMapping("/admin/id/{Id}")
	public Admin getAdminById(@PathVariable int Id )
	{
		Admin cust = service.getAdminId(Id);
		
		return cust;
	}
	

	@GetMapping("/admin/email/{email}")
	public Admin getByEmail(@PathVariable String email) {
		Admin cust = service.getAdminByEmail(email);
		return cust;
		
	}
	
	
	
	@Transactional
	@PutMapping("/admin/pass/{Id}/{pass}")
	public ResponseEntity<Admin> updatePasswordByAdminId(@PathVariable int id,@PathVariable String pass)
	{
		Admin c = service.getAdminId(id);
		int res= 0;
		if(c!=null) {
			res = service.updatePasswordByadminId(id, pass);
			if(res>0) {
				c = service.getAdminId(id);
			}
		}
		return new ResponseEntity<Admin>(c,HttpStatus.OK) ;
	}


	
	

}
