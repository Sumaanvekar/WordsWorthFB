package com.slk.demo.WordsWorth.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.slk.demo.WordsWorth.entity.Supplier;
import com.slk.demo.WordsWorth.service.SupplierService;



@RestController
@RequestMapping("/api")
@CrossOrigin(origins="http://localhost:4200")
public class SupplierController {

	@Autowired
	private SupplierService service;
	
	@GetMapping("/suppliers")
	public List<Supplier> listAllSupplier(){
		return service.listAllSupplier();
	}
	@GetMapping("/supplier/{theId}")
	public Supplier getSupplier(@PathVariable int theId )
	{
		Supplier sp = service.getSupplierById(theId);
		
		return sp;
	}
	@GetMapping("/supplier/email/{emailId}")
	public Supplier getByEmail(@PathVariable String emailId) {
		Supplier sp = service.getSupplierByEmail(emailId);
		return sp;
		
	}
	
	@PostMapping("/suppliers")
	public Supplier addSupplier(@RequestBody Supplier theSupplier )
	{
		//theAdmin.setAdminId("");
		Supplier sp = service.save(theSupplier);
		return sp;
	}
	
	@PutMapping("/supplier")
	public Supplier updateSupplier(@RequestBody Supplier theSupplier )
	{
		
		Supplier sp = service.save(theSupplier);
		return sp;
	}
	
	
	@DeleteMapping("/supplier/{theId}")
	public void deleteBySupplierId(@PathVariable int theId)
	{
		service.deleteById(theId);
		Supplier st = service.getSupplierById(theId);
	    
	}
	
	
	
	
	
	
	
}

