package com.slk.demo.WordsWorth.entity;

import java.sql.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="ORDERS")
//@SequenceGenerator(name="MySequence",sequenceName="order_sequence",initialValue=50,allocationSize=1)

public class Order {
	@Id
//	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="MySequence")
	@Column(name="ORDERID")
	private int orderId;
	
	@Column(name="CUSTOMERID")
	private int customerId;
	
	@Column(name="BOOKID")
	private int bookId;
	
	@Column(name="QUANTITY")
	private int quantity;
	
	@Column(name="TOTALPRICE")
	private long totalPrice;
	
	@Column(name="ORDERDATE")
	private  Date orderDate;
	
	@Column(name="PAYMENTSTATUS")
	private String paymentStatus;
	
	@Column(name="ORDERSTATUS")
	private String orderStatus;
	
	@Column(name="DELIVERYDATE")
	private Date deliveryDate;
	
	public Order() {
	 
	}
    /// Parameterise Constructor
	public Order(int orderId, int customerId, int bookId, int quantity, long totalPrice, Date orderDate,
			String paymentStatus, String orderStatus, Date deliveryDate) {
		super();
		this.orderId = orderId;
		this.customerId = customerId;
		this.bookId = bookId;
		this.quantity = quantity;
		this.totalPrice = totalPrice;
		this.orderDate = orderDate;
		this.paymentStatus = paymentStatus;
		this.orderStatus = orderStatus;
		this.deliveryDate = deliveryDate;
	}

	@Override
	public int hashCode() {
		return Objects.hash(deliveryDate, orderDate, orderId, orderStatus, paymentStatus, quantity, totalPrice);
	}

	
	public int getOrderId() {
		return orderId;
	}


	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}


	public int getCutomerId() {
		return customerId;
	}


	public void setCutomerId(int cutomerId) {
		this.customerId = cutomerId;
	}


	public int getBookId() {
		return bookId;
	}


	public void setBookId(int bookId) {
		this.bookId = bookId;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	public long getTotalPrice() {
		return totalPrice;
	}


	public void setTotalPrice(long totalPrice) {
		this.totalPrice = totalPrice;
	}


	public Date getOrderDate() {
		return orderDate;
	}


	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}


	public String getPaymentStatus() {
		return paymentStatus;
	}


	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}


	public String getOrderStatus() {
		return orderStatus;
	}


	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}


	public Date getDeliveryDate() {
		return deliveryDate;
	}


	public void setDeliveryDate(Date deliveryDate) {
		this.deliveryDate = deliveryDate;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order other = (Order) obj;
		return Objects.equals(deliveryDate, other.deliveryDate) && Objects.equals(orderDate, other.orderDate)
				&& orderId == other.orderId && Objects.equals(orderStatus, other.orderStatus)
				&& Objects.equals(paymentStatus, other.paymentStatus) && quantity == other.quantity
				&& totalPrice == other.totalPrice;
	}
	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", cutomerId=" + customerId + ", bookId=" + bookId + ", quantity="
				+ quantity + ", totalPrice=" + totalPrice + ", orderDate=" + orderDate + ", paymentStatus="
				+ paymentStatus + ", orderStatus=" + orderStatus + ", deliveryDate=" + deliveryDate + "]";
	}


	
	
}
