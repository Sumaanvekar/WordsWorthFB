package com.slk.demo.WordsWorth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WordsWorthApplicationTests {

	@Test
	void contextLoads() {
	}

}
